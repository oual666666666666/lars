#pragma once

/*
 * 定义一些IO复用机制或者其他异常触发机制的事件封装
 *
 * */
class event_loop;

//IO事件触发的回调函数指针
//先定义出函数的类型，再通过类型定义函数指针变量
typedef void io_callback(event_loop*, int , void*);

//封装一次IO触发的事件
struct io_event
{
    io_event():mask(0),read_callback(nullptr),write_callback(nullptr),
        rcb_args(nullptr),wcb_args(nullptr){}

    //事件的读写属性
    int mask;   //EPOLLIN EPOLLOUT

    //读事件触发所绑定的回调函数
    io_callback *read_callback;

    //写事件触发所绑定的回调函数
    io_callback *write_callback;

    //读事件回调函数的形参
    void *rcb_args;

    //写事件回调函数的形参
    void *wcb_args;
};
