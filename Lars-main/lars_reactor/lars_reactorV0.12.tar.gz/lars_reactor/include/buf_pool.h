#pragma once

#include <unordered_map>
#include "io_buf.h"

//定义一些内存的刻度
enum MEM_CAP
{
    m4K = 4096,
    m16K = 16384,
    m64K = 65536,
    m256K = 262144,
    m1M = 1048576,
    m4M = 4194304,
    m8M = 8388608
};

//总内存池最大限制 单位是Kb 目前限制是 4GB
#define MEM_LIMIT (4U *1024 *1024) 

//使用单例模式实现
class BUF_POOL
{
public:
    //初始化单例对象
    static void init()
    {
        _instance = new BUF_POOL();
    }
    //提供一个静态的获取单例的方法
    static BUF_POOL* instance()
    {
        pthread_once(&_once, init);
        return _instance;
    }

    //从内存池中申请一块内存
    IO_BUF *alloc_buf(int N);
    IO_BUF *alloc_buf();

    //重置一个io_buf
    void revert(IO_BUF *buffer);

    //预先分配内存
    void make_io_buf_list(int cap, int num);

private:
    //构造函数私有
    BUF_POOL();
    BUF_POOL(const BUF_POOL &);
    const BUF_POOL &operator=(const BUF_POOL &);

    //单例的对象
    static BUF_POOL *_instance;

    //用于保证创建单例的init方法只执行一次的锁
    static pthread_once_t _once;

    //============内存池属性=============
    //存放所有io_buf的map句柄
    std::unordered_map<int, IO_BUF *> _pool;

    //当前内存池总体大小
    uint64_t _total_mem;

    static pthread_mutex_t _mutex;
};