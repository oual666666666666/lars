#pragma once

/*
* 定义一个buffer存放数据的结构
*/

class IO_BUF
{
public:
    //构造函数，创建一个size大小的buf
    IO_BUF(int size);

    //清空数据
    void clear();

    //处理长度为len的数据 移动head
    void pop(int len);

    //将已经处理的数据清空，将未处理的数据移到buf的首地址，length会减小
    void adjust();

    //将其他的io_buf对象拷贝到自己
    void copy(const IO_BUF *other);

    //buffer的缓存容量大小
    int capacity;

    //buffer的有效数据长度
    int length;

    //未处理数据的头部索引位置
    int head;

    //io_buf的首地址
    char *data;

    //指向下一个io_buf的地址
    IO_BUF *next;
};