#pragma once

#include <netinet/in.h>
#include "event_loop.h"
#include "tcp_conn.h"
#include "message.h"
#include "thread_pool.h"

class TCP_SERVER
{
public:
    //构造函数
    TCP_SERVER(event_loop *loop, const char *ip, uint16_t port);

    //开始提供创建连接的服务
    void do_accept();

    //析构函数 释放资源
    ~TCP_SERVER();

private:
    int _sockfd; //套接字 监听文件描述符
    struct sockaddr_in _connaddr; //客户端链接地址
    socklen_t _addrlen; //客户端连接地址长度

    // event_loop epoll的多路IO复用机制
    event_loop *_loop;

//---- 客户端链接管理部分-----
public:
    //全部已经在线的连接信息
    static tcp_conn **conns;
    //新增一个链接
    static void increase_conn(int connfd, tcp_conn *conn);
    //减少一个链接
    static void decrease_conn(int connfd);
    //得到当前的链接个数
    static void get_conn_num(int *curr_conn);

    static int _max_conns;          //最大client链接个数
    static int _curr_conns;         //当前链接个数
    static pthread_mutex_t _conns_mutex; //保护_curr_conns的锁

//---- 消息分发路由部分-----
public:
    //提供一个添加路由的方法
    void add_msg_router(int msgid, msg_callback *cb, void *user_data = nullptr) 
    {
        router.register_msg_router(msgid, cb, user_data);
    }

    //添加一个路由分发机制句柄
    static msg_router router;

// ------- 创建链接/销毁链接 Hook 部分 -----
    //设置链接的创建hook函数 API
    static void set_conn_start(conn_callback cb, void *args = nullptr) 
    {
        conn_start_cb = cb;
        conn_start_cb_args = args;
    }

    //设置链接的销毁hook函数 API
    static void set_conn_close(conn_callback cb, void *args = nullptr) 
    {
        conn_close_cb = cb;
        conn_close_cb_args = args;
    }

    //创建链接之后要触发的 回调函数
    static conn_callback conn_start_cb;
    static void *conn_start_cb_args;

    //销毁链接之前要触发的 回调函数
    static conn_callback conn_close_cb;
    static void *conn_close_cb_args;

    //获取当前server的线程池
    thread_pool *get_thread_pool()
    {
        return _thread_pool;
    }

// ------- 线程池 部分 -----
private:
    thread_pool *_thread_pool;
};
