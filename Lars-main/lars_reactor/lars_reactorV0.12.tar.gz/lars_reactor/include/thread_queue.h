#pragma once
#include <stdio.h>
#include <unistd.h>
#include <sys/eventfd.h>
#include <pthread.h>
#include <queue>
#include "event_loop.h"
/*
 * 每个thread对应的 消息任务队列
 * */

template <typename T>
class thread_queue
{
public:
    thread_queue()
    {
        _loop = nullptr;
        pthread_mutex_init(&_queue_mutex, NULL);
        //创建一个fd用来被监听,没有跟磁盘和socket相关联
        _evfd = eventfd(0, EFD_NONBLOCK);
        if (_evfd == -1) 
        {
            perror("evenfd(0, EFD_NONBLOCK)");
            exit(1);
        }
    }

    ~thread_queue()
    {
        pthread_mutex_destroy(&_queue_mutex);
        close(_evfd);
    }

    //向队列中添加一个任务（main_thread调用其他业务功能线程来调用）
    void send(const T &task)
    {
        unsigned long long idle_num = 1;

        //将task加入到_queue中，激活_evfd
        pthread_mutex_lock(&_queue_mutex);
        _queue.push(task);

        //激活_evfd可读事件，向_evfd写数据
        int ret = write(_evfd, &idle_num, sizeof(unsigned long long));
        if (ret == -1) {
            perror("_evfd write");
        }

        pthread_mutex_unlock(&_queue_mutex);
    }

    //从队列中取数据,将整个queue返回给上层,queue_msgs传出参数,被_evfd激活的读事件业务函数来调用
    void recv(std::queue<T>& queue_msgs)
    {
        unsigned long long idle_num = 1;

        pthread_mutex_lock(&_queue_mutex);
        int ret = read(_evfd, &idle_num, sizeof(unsigned long long));
        if (ret == -1) {
            perror("_evfd read");
        }

        //交换两个容器的指针，确保queue_msgs是空队列，这样交换之后，_queue才为空
        std::swap(queue_msgs, _queue);        

        pthread_mutex_unlock(&_queue_mutex);
    }

    //设置当前thead_queue是被哪个event_loop监控
    void set_loop(event_loop *loop) 
    {
        _loop = loop;  
    }

    //设置当前消息任务队列的 每个任务触发的回调业务
    void set_callback(io_callback *cb, void *args = nullptr)
    {
        if (_loop != nullptr) {
            _loop->add_io_event(_evfd, cb, EPOLLIN, args);
        }
    }

    //得到当前loop
    event_loop * get_loop() {
        return _loop;
    }

private:
    //让某个线程进行监听的fd
    int _evfd;    
    //目前被哪个event_loop监听 
    event_loop *_loop; 
    //队列   
    std::queue<T> _queue; 
    //进行添加任务、读取任务的保护锁 
    pthread_mutex_t _queue_mutex; 
};