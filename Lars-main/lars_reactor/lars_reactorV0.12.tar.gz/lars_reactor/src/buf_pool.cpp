#include "buf_pool.h"
#include <assert.h>

//单例的对象
BUF_POOL *BUF_POOL::_instance = nullptr;
//用于保证创建单例的init方法只执行一次的锁
pthread_once_t BUF_POOL::_once = PTHREAD_ONCE_INIT;
//初始化互斥锁
pthread_mutex_t BUF_POOL::_mutex = PTHREAD_MUTEX_INITIALIZER;

//构造函数 主要是预先开辟一定量的空间
//这里buf_pool是一个hash，每个key都是不同空间容量
//对应的value是一个io_buf集合的链表
//buf_pool -->  [m4K] -- io_buf-io_buf-io_buf-io_buf...
//              ...

//构造函数
BUF_POOL::BUF_POOL():_total_mem(0)
{
    make_io_buf_list(m4K, 5000);
    make_io_buf_list(m16K, 1000);
    make_io_buf_list(m64K, 500);
    make_io_buf_list(m256K, 200);
    make_io_buf_list(m1M, 50);
    make_io_buf_list(m4M, 20);
    make_io_buf_list(m8M, 10);
    if (_total_mem > MEM_LIMIT)
    {
        return;
    }
}

//预先分配内存
void BUF_POOL::make_io_buf_list(int cap, int num)
{
        //链表的头指针
    IO_BUF *prev;

    //开辟4K buf 内存池
    _pool[cap] = new IO_BUF(cap);
    if (_pool[cap] == nullptr)
    {
        fprintf(stderr, "new io_buf %d error",cap);
        exit(1);
    }
    prev = _pool[cap];

    for (int i = 1; i < num;i++)
    {
        prev->next = new IO_BUF(cap);
        if(prev->next==nullptr)
        {
            fprintf(stderr, "new io_buf %d error",cap);
            exit(1);
        }
        prev = prev->next;
    }
    _total_mem += cap/1024 * num;
}
//从内存池中申请一块内存
//1 如果上层需要N个字节的大小的空间，找到与N最接近的buf hash组，取出，
//2 如果该组已经没有节点使用，可以额外申请
//3 总申请长度不能够超过最大的限制大小 EXTRA_MEM_LIMIT
//4 如果有该节点需要的内存块，直接取出，并且将该内存块从pool摘除
IO_BUF *BUF_POOL::alloc_buf(int N)
{
    //1 找到N最接近哪个hash组
    int index;
    if (N <= m4K) {
        index = m4K;
    }
    else if (N <= m16K) {
        index = m16K;
    }
    else if (N <= m64K) {
        index = m64K;
    }
    else if (N <= m256K) {
        index = m256K;
    }
    else if (N <= m1M) {
        index = m1M;
    }
    else if (N <= m4M) {
        index = m4M;
    }
    else if (N <= m8M) {
        index = m8M;
    }
    else {
        return nullptr;
    }

    pthread_mutex_lock(&_mutex);
    //2 如果该组已经没有，需要额外申请
    if (_pool[index] == nullptr)
    {
        if (_total_mem + index/1024 >= MEM_LIMIT)
        {
            //当前的开辟的空间已经超过最大限制
            fprintf(stderr, "already use too many memory!\n");
            exit(1);
        }

        IO_BUF *new_buf = new IO_BUF(index);
        if (new_buf == nullptr) {
            fprintf(stderr, "new io_buf error\n");
            exit(1);
        }
        _total_mem += index/1024;
        pthread_mutex_unlock(&_mutex);
        return new_buf;
    }

    //3 如果该组有，从pool中摘除该内存块
    IO_BUF *target = _pool[index];
    _pool[index] = target->next;
    pthread_mutex_unlock(&_mutex);
    
    target->next = nullptr;
    
    return target;
}

IO_BUF *BUF_POOL::alloc_buf()
{
    return alloc_buf(m4K);
}

//重置一个io_buf
void BUF_POOL::revert(IO_BUF *buffer)
{
    //将buffer放回pool中
    int index = buffer->capacity;

    buffer->length = 0;
    buffer->head = 0;

    pthread_mutex_lock(&_mutex);
    //找到对应的hash组 buf首节点地址
    assert(_pool.find(index) != _pool.end());
    //将buffer插回链表头部
    buffer->next = _pool[index];
    _pool[index] = buffer;
    pthread_mutex_unlock(&_mutex);

}
